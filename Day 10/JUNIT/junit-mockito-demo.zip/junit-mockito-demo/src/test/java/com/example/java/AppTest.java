package com.example.java;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Unit test for simple App.
 */
@DisplayName("JUNIT Standard Test Class Example")
public class AppTest {

	@Test
	public void succeedTest() {

		System.out.println("SucceddingTest() executed...");
	}

	@Test
	public void failingTest() {
		System.out.println("failingTest()");
		Assertions.fail("a failing test");
	}

	@DisplayName("Check If String abc contains string z")
	@Test
	public void checkIfCharacterZExistsinStringABC() {
		System.out.println("within checkIfCharacterZExistsinStringABC");
		Assertions.assertTrue("abc".contains("z"));
	}

	@DisplayName("Check If String is NULL")
	@Test
	public void checkIfStringIsNull() {
		System.out.println("within checkIfStringIsNull");
		String str=null;
		Assertions.assertNull(str);
		
	}
}
