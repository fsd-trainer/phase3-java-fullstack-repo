package com.example.java;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

public class TestEmployeeService {

	@Test
	public void TestRetreieveEmployeeList_UsingMock() {

		EmployeeDAO employeeDAOMock = Mockito.mock(EmployeeDAO.class);
		
		List<Employee> list = new ArrayList<Employee>();
		list.add(new Employee(1,  "john"));
		list.add(new Employee(2,  "Jill"));
		
		//  Use WHEN THEN Style
	    when(employeeDAOMock.getEmployeeList()).thenReturn(list);
	    
	    // ARRANGE
	    EmployeeService employeeService = new EmployeeService(employeeDAOMock);
	    
	    // ACT
	   List<Employee>  returnedList =   employeeService.getEmployeeList();

	   // ASSERT
	   Assertions.assertEquals(returnedList.size(), 2);
	
	}
}
