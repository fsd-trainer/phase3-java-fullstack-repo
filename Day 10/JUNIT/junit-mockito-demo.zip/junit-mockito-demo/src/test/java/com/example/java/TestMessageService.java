package com.example.java;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Testing MessageService class Methods")
public class TestMessageService {

	public MessageService messageService;

	@BeforeAll
	public static void init() {
		System.out.println("Should be called before all test cases are executed..\n");
	}

	@BeforeEach
	public void setup() {
		System.out.println("Executed before each test case");
		messageService = new MessageService();
	}

	@AfterEach
	public void tearDown() {
		System.out.println("Called after each test case is completed..");
		System.out.println("Should be used to close db connection or file...\n\n");
	}

	@AfterAll
	public static void done() {
		System.out.println("Called after all test cases are completed..");
	}

	@DisplayName("Message Object Not Null")
	@Test
	public void shouldReturnTrueForNotNullMessageObject() {

		System.out.println("Within Message Object Not Null test case");
		
		// Arrange

		// ACT

		// Assert
		Assertions.assertNotNull(messageService);
	}

	@DisplayName("String Value Hello Length should be 5")
	@Test
	public void shouldReturnLengthFour_ForPassedStringVlaue_Hello() {

		System.out.println("Within String Value Hello Length should be 5 test case");
		
		// ARRANGE
		String str = "hello";
		int returnLength;

		// ACT - ask test to run the method on object and obtain result
		returnLength = messageService.checkStringLength(str);

		// ASSERT - call assertEquals(expected, actual);
		Assertions.assertEquals(5, returnLength);
	}

	@DisplayName("String Length Does Not Match Expected Value 6")
	@Test
	public void shouldFail_WhenExpected_Is6_ForPassedStringVlaue_Hello() {
		System.out.println("String Length Does Not Match Expected Value 6");

		// ARRANGE
		String str = "hello";
		int returnLength;

		// ACT - ask test to run the method on object and obtain result
		returnLength = messageService.checkStringLength(str);

		// ASSERT - call assertEquals(expected, actual);
		Assertions.assertEquals(6, returnLength);
	}
}
