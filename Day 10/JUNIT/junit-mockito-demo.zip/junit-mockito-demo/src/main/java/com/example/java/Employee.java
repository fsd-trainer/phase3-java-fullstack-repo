package com.example.java;

public class Employee {

	private int employeeid;
	private String employeeName;

	public Employee(int employeeid, String employeeName) {
		this.employeeid = employeeid;
		this.employeeName = employeeName;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

}
