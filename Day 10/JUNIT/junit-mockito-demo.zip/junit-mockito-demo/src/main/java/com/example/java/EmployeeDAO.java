package com.example.java;

import java.util.List;

public class EmployeeDAO {
	
	public List<Employee> getEmployeeList(){
		// write logic to retrieve employee details from employee table in DB
		return null;
	}
	
	public void addEmployee(Employee employee) {
		// write code here to add new Employee object in DB
	}

}
