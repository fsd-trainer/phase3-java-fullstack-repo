package com.example.java;

import java.util.List;

public class EmployeeService {

	EmployeeDAO dao;

	public EmployeeService(EmployeeDAO employeeDAO) {
		this.dao = employeeDAO;
	}
	public List<Employee> getEmployeeList() {
		return this.dao.getEmployeeList();
	}

	public void addEmployee(Employee employee) {
		this.dao.addEmployee(employee);
	}
}
