package com.example.java;

public class MessageService {

	
	public int checkStringLength(String message) {
		System.out.println("within MessageService class method - checkStringLength");
		return message.length();
    }
	
}
